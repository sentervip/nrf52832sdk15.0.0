#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include "nrf.h"
#include "nrf_drv_saadc.h"
#include "nrf_drv_ppi.h"
#include "nrf_drv_timer.h"
#include "boards.h"
#include "app_error.h"
#include "nrf_delay.h"
#include "app_util_platform.h"
#include "nrf_log.h"
#include "nrf_log_ctrl.h"
#include "nrf_log_default_backends.h"
#include <nrf_delay.h>

#define ENABLE    1
#define DISABLE   0
#define SAMPLES_IN_BUFFER 4
typedef enum{
	LEVEL1=1,
	LEVEL2=2,
	LEVEL3=4,
	LEVEL4=8,
	ALL_LEVEL=0xf
}tagCapLevel;

typedef enum{
	RESET_ALL,
	STOP_CAP,
	START_CAP,
	DISABLE_ADC,
	ENABLE_ADC,
}tagCapCmd;

typedef struct{
	nrf_drv_timer_t timer;
	nrf_saadc_value_t     buf[SAMPLES_IN_BUFFER];
	nrf_ppi_channel_t     ppiChannel;
	uint8_t               lock;
	uint8_t               levelEnable;
	const uint16_t *      pLevelData;
}TagAppAdc;
extern TagAppAdc  g_str_app_adc;
void saadc_init(void);
void saadc_sampling_event_init(void);
void saadc_sampling_event_enable(void);
void saadc_sampling_event_disable(void);
void captrue_cmd(uint8_t type);
